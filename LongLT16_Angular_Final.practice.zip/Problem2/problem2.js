//LongLT16_Angular_Final.practice

var mt = [
     [0, 0, 0, 1, 0, 0, 1],
     [0, 1, 1, 1, 0, 0, 1],
     [0, 0, 0, 0, 0, 0, 0]
]
var mt2 = [
     [0, 0, 0, 1, 0, 0, 1],
     [0, 1, 1, 1, 0, 0, 1],
     [0, 0, 0, 0, 0, 1, 0]
]
var mt3 = [
     [0, 0, 0, 1, 0, 0, 1],
     [1, 1, 1, 1, 0, 0, 1],
     [0, 0, 0, 0, 0, 0, 0]
]
var m4 = [
     [0, 0, 0, 1, 0, 0, 1],
     [0, 1, 1, 1, 0, 0, 1],
     [0, 0, 0, 0, 0, 0, 1]
]

function findPath(matrix) {
     if(Array.isArray(matrix)){
          let [a, b, c] = [...matrix]

          var path = ''

          let i = 1

          for(; i < a.length; i++) {
               if(a[i] == 0) {
                    path += 'R'
               }
               else{
                    path += 'D'
                    continue;
               }
          }

          for(; i < b.length; i++){
               if(b[i] == 0){
                    path += 'R'
               }
               else{
                    path += 'D'
                    continue;
               }
          }

          for(; i<c.length; i++)
          if(c[i] == 0){
               path += 'R'
          }
          else{
               path += 'D'
               continue;
          }
     }
     return path
}


console.log(findPath(mt));

